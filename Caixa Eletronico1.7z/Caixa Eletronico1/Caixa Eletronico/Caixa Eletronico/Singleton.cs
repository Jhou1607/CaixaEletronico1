﻿using Caixa_Eletronico.Classes;

namespace Caixa_Eletronico
{
    public sealed class Singleton
    {
        private Singleton()
        {
            contas = new List<Conta>() { new CCorrente("123", 200), new CPoupanca("1") };
        }

        private static Singleton _instance;
        public static Singleton Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new Singleton();
                }
                return _instance;
            }
        }

        public List<Conta> contas;

        public Conta BuscarConta(string numero)
        {
            if (contas == null || contas.Count == 0)
            {
                return null;
            }

            Conta c = contas.Find(c => c.Numero == numero);
            return c;
        }
    }
}
