﻿using Caixa_Eletronico.Classes;

namespace Caixa_Eletronico
{
    public partial class OperacoesForm : Form
    {
        private Conta conta;

        public OperacoesForm(Conta conta)
        {
            InitializeComponent();
            this.conta = conta;
            AtualizarSaldo();
        }

        public void AtualizarSaldo()
        {
            lblSaldo.Text = $"R$ {conta.Saldo:C2}";
        }

        private void btnDepositar_Click(object sender, EventArgs e)
        {
            RealizarOperacaoForm realizarOperacaoForm = new RealizarOperacaoForm(conta, TipoOperacao.Depositar);
            realizarOperacaoForm.Show();
            this.Hide();
        }

        private void btnSacar_Click_1(object sender, EventArgs e)
        {
            RealizarOperacaoForm realizarOperacaoForm = new RealizarOperacaoForm(conta, TipoOperacao.Sacar);
            realizarOperacaoForm.Show();
            this.Hide();
        }

        private void btnTransferir_Click_1(object sender, EventArgs e)
        {
            RealizarOperacaoForm realizarOperacaoForm = new RealizarOperacaoForm(conta, TipoOperacao.Transferir);
            realizarOperacaoForm.Show();
            this.Hide();
        }

        private void btnVerExtrato_Click_1(object sender, EventArgs e)
        {
            RealizarOperacaoForm realizarOperacaoForm = new RealizarOperacaoForm(conta, TipoOperacao.VerExtrato);
            realizarOperacaoForm.Show();
            this.Hide();
        }

        private void btnVoltar_Click(object sender, EventArgs e)
        {
            FrmInicial Ini = new FrmInicial();
            this.Hide();
            Ini.Show();
        }
    }
}
