﻿using Caixa_Eletronico.Classes;

namespace Caixa_Eletronico
{
    public partial class RealizarOperacaoForm : Form
    {
        private Conta conta;
        private TipoOperacao tipoOperacao;

        public RealizarOperacaoForm(Conta conta, TipoOperacao tipoOperacao)
        {
            InitializeComponent();
            this.conta = conta;
            this.tipoOperacao = tipoOperacao;
            switch (tipoOperacao)
            {
                case TipoOperacao.Depositar:
                    lblOperacao.Text = "Depositar";
                    lblContaDestino.Visible = false;
                    txtContaDestino.Visible = false;
                    break;
                case TipoOperacao.Sacar:
                    lblOperacao.Text = "Sacar";
                    lblContaDestino.Visible = false;
                    txtContaDestino.Visible = false;
                    break;
                case TipoOperacao.Transferir:
                    lblOperacao.Text = "Transferir";
                    lblContaDestino.Visible = true;
                    txtContaDestino.Visible = true;
                    break;
                case TipoOperacao.VerExtrato:
                    lblOperacao.Text = "Ver Extrato";
                    lblContaDestino.Visible = false;
                    txtContaDestino.Visible = false;
                    numValor.Visible = false;
                    btnConfirmar.Visible = false;
                    GerarExtrato();
                    break;
            }
        }

        private void btnConfirmar_Click(object sender, EventArgs e)
        {
            double valor = Convert.ToDouble(numValor.Value);
            switch (tipoOperacao)
            {
                case TipoOperacao.Depositar:
                    conta.Depositar(valor);
                    MessageBox.Show("Depósito realizado com sucesso.");
                    break;
                case TipoOperacao.Sacar:
                    bool sucesso = conta.Sacar(valor);
                    if (!sucesso)
                    {
                        MessageBox.Show("Saldo insuficiente.");
                    }
                    else
                    {
                        MessageBox.Show("Saque realizado com sucesso.");
                    }
                    break;
                case TipoOperacao.Transferir:
                    string numeroContaDestino = txtContaDestino.Text;
                    Conta contaDestino = Singleton.Instance.BuscarConta(numeroContaDestino);
                    if (contaDestino != null)
                    {
                        bool transferenciaSucesso = conta.Transferir(contaDestino, valor);
                        if (transferenciaSucesso)
                        {
                            MessageBox.Show("Transferência realizada com sucesso.");
                        }
                        else
                        {
                            MessageBox.Show("Transferência falhou. Verifique o saldo ou a conta de destino.");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Conta de destino não encontrada.");
                    }
                    break;
            }
            VoltarParaOperacoesForm();
        }

        private void GerarExtrato()
        {
            List<Transacao> extrato = conta.GerarExtrato();
            string detalhesExtrato = "";
            foreach (Transacao t in extrato)
            {
                detalhesExtrato += $"Tipo: {t.Tipo}, Valor: {t.Valor:C2}\n";
            }
            MessageBox.Show(detalhesExtrato, "Extrato");
        }

        private void btnVolta_Click(object sender, EventArgs e)
        {
            VoltarParaOperacoesForm();
        }

        private void VoltarParaOperacoesForm()
        {
            OperacoesForm operacoesForm = Application.OpenForms.OfType<OperacoesForm>().FirstOrDefault();
            if (operacoesForm != null)
            {
                operacoesForm.Show();
                operacoesForm.AtualizarSaldo();
                this.Close();
            }
            else
            {
                this.Close();
            }
        }
    }
}
