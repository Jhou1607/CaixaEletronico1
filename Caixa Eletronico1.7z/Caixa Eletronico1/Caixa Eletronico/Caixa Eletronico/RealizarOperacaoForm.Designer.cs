﻿namespace Caixa_Eletronico
{
    partial class RealizarOperacaoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblOperacao = new Label();
            numValor = new NumericUpDown();
            btnConfirmar = new Button();
            lblContaDestino = new Label();
            txtContaDestino = new TextBox();
            btnVolta = new Button();
            ((System.ComponentModel.ISupportInitialize)numValor).BeginInit();
            SuspendLayout();
            // 
            // lblOperacao
            // 
            lblOperacao.AutoSize = true;
            lblOperacao.Location = new Point(218, 192);
            lblOperacao.Name = "lblOperacao";
            lblOperacao.Size = new Size(81, 20);
            lblOperacao.TabIndex = 0;
            lblOperacao.Text = "Operação: ";
            // 
            // numValor
            // 
            numValor.Location = new Point(392, 193);
            numValor.Name = "numValor";
            numValor.Size = new Size(150, 27);
            numValor.TabIndex = 1;
            // 
            // btnConfirmar
            // 
            btnConfirmar.Location = new Point(311, 304);
            btnConfirmar.Name = "btnConfirmar";
            btnConfirmar.Size = new Size(94, 29);
            btnConfirmar.TabIndex = 2;
            btnConfirmar.Text = "Confirmar";
            btnConfirmar.UseVisualStyleBackColor = true;
            btnConfirmar.Click += btnConfirmar_Click;
            // 
            // lblContaDestino
            // 
            lblContaDestino.AutoSize = true;
            lblContaDestino.Location = new Point(219, 253);
            lblContaDestino.Name = "lblContaDestino";
            lblContaDestino.Size = new Size(110, 20);
            lblContaDestino.TabIndex = 3;
            lblContaDestino.Text = "Conta Destino: ";
            // 
            // txtContaDestino
            // 
            txtContaDestino.Location = new Point(392, 246);
            txtContaDestino.Name = "txtContaDestino";
            txtContaDestino.Size = new Size(125, 27);
            txtContaDestino.TabIndex = 4;
            // 
            // btnVolta
            // 
            btnVolta.Location = new Point(63, 103);
            btnVolta.Name = "btnVolta";
            btnVolta.Size = new Size(94, 29);
            btnVolta.TabIndex = 5;
            btnVolta.Text = "Voltar";
            btnVolta.UseVisualStyleBackColor = true;
            btnVolta.Click += btnVolta_Click;
            // 
            // RealizarOperacaoForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnVolta);
            Controls.Add(txtContaDestino);
            Controls.Add(lblContaDestino);
            Controls.Add(btnConfirmar);
            Controls.Add(numValor);
            Controls.Add(lblOperacao);
            Name = "RealizarOperacaoForm";
            Text = "RealizarOperacaoForm";
            ((System.ComponentModel.ISupportInitialize)numValor).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblOperacao;
        private NumericUpDown numValor;
        private Button btnConfirmar;
        private Label lblContaDestino;
        private TextBox txtContaDestino;
        private Button btnVolta;
    }
}