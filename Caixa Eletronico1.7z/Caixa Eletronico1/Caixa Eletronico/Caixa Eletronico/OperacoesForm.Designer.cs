﻿namespace Caixa_Eletronico
{
    partial class OperacoesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnDepositar = new Button();
            btnSacar = new Button();
            btnTransferir = new Button();
            btnVerExtrato = new Button();
            btnVoltar = new Button();
            label1 = new Label();
            lblSaldo = new Label();
            SuspendLayout();
            // 
            // btnDepositar
            // 
            btnDepositar.Location = new Point(330, 200);
            btnDepositar.Name = "btnDepositar";
            btnDepositar.Size = new Size(94, 29);
            btnDepositar.TabIndex = 0;
            btnDepositar.Text = "Depositar";
            btnDepositar.UseVisualStyleBackColor = true;
            btnDepositar.Click += btnDepositar_Click;
            // 
            // btnSacar
            // 
            btnSacar.Location = new Point(330, 235);
            btnSacar.Name = "btnSacar";
            btnSacar.Size = new Size(94, 29);
            btnSacar.TabIndex = 1;
            btnSacar.Text = "Sacar";
            btnSacar.UseVisualStyleBackColor = true;
            btnSacar.Click += btnSacar_Click_1;
            // 
            // btnTransferir
            // 
            btnTransferir.Location = new Point(330, 270);
            btnTransferir.Name = "btnTransferir";
            btnTransferir.Size = new Size(94, 29);
            btnTransferir.TabIndex = 2;
            btnTransferir.Text = "Transferir";
            btnTransferir.UseVisualStyleBackColor = true;
            btnTransferir.Click += btnTransferir_Click_1;
            // 
            // btnVerExtrato
            // 
            btnVerExtrato.Location = new Point(330, 305);
            btnVerExtrato.Name = "btnVerExtrato";
            btnVerExtrato.Size = new Size(94, 29);
            btnVerExtrato.TabIndex = 3;
            btnVerExtrato.Text = "Ver Extrato";
            btnVerExtrato.UseVisualStyleBackColor = true;
            btnVerExtrato.Click += btnVerExtrato_Click_1;
            // 
            // btnVoltar
            // 
            btnVoltar.Location = new Point(142, 119);
            btnVoltar.Name = "btnVoltar";
            btnVoltar.Size = new Size(94, 29);
            btnVoltar.TabIndex = 4;
            btnVoltar.Text = "Voltar";
            btnVoltar.UseVisualStyleBackColor = true;
            btnVoltar.Click += btnVoltar_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(529, 119);
            label1.Name = "label1";
            label1.Size = new Size(50, 20);
            label1.TabIndex = 5;
            label1.Text = "Saldo:";
            // 
            // lblSaldo
            // 
            lblSaldo.AutoSize = true;
            lblSaldo.Location = new Point(585, 119);
            lblSaldo.Name = "lblSaldo";
            lblSaldo.Size = new Size(0, 20);
            lblSaldo.TabIndex = 6;
            // 
            // OperacoesForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblSaldo);
            Controls.Add(label1);
            Controls.Add(btnVoltar);
            Controls.Add(btnVerExtrato);
            Controls.Add(btnTransferir);
            Controls.Add(btnSacar);
            Controls.Add(btnDepositar);
            Name = "OperacoesForm";
            Text = "OperacoesForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Button btnDepositar;
        private System.Windows.Forms.Button btnSacar;
        private System.Windows.Forms.Button btnTransferir;
        private System.Windows.Forms.Button btnVerExtrato;
        private Button btnVoltar;
        private Label label1;
        private Label lblSaldo;
    }
}
